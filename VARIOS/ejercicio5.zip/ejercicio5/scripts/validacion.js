/** Ejercicio 5
 * Variación sobre el ejercicio anterior.
 * Cuando se detecte un fallo de validación desactivar todos los controles
 * del formulario salvo el que ha dado fallo. Cuando la validación sea válida,
 * volver a activar los controles que estén desactivados.
 * Utilizar la propiedad disabled para activar o desactivar
 */

const pedido = {
    datosEntrega: {
      nombre: document.getElementById("nombre"),
      telefono: document.getElementById("telefono"),
      direccion: document.getElementById("direccion"),
      instrucciones: document.getElementById("instrucciones"),
      toString() {
        return Object.values(this).map(e => e.value).flat().join(', ');
      },
    },
  
    ingredientes: {
      queso: document.getElementById("queso"),
      champi: document.getElementById("champiñones"),
      cebolla: document.getElementById("cebolla"),
      pimiento: document.getElementById("pimiento"),
      toString() {
        return Object.keys(this).reduce((acc, cur) =>
          this[cur].checked ? [...acc, cur] : acc, []).join(', ');
      },
    },
  
    formaPago: document.getElementById("forma-pago"),
    tiposPizza: document.getElementById("tipos"),
  
    resumen(visor) {
      visor.innerHTML = `<p>Datos de entrega: ${this.datosEntrega.toString()}</p>`;
      visor.innerHTML += `<p>Ingredientes: ${this.ingredientes.toString()}</p>`;
    },
};

const visor = document.getElementById('resumen');

function habilitarControles(controles, disabled) {
  controles.forEach(control => control.disabled = !disabled);
}

document.forms[0].addEventListener('focusout', function({ target }) {
    const filtroControles = ctrl => ctrl !== target && ctrl.tagName !== 'FIELDSET';
    let otrosControles = [...document.forms[0].elements].filter(filtroControles);
    let ctrlValido = target.validity.valid;

    habilitarControles(otrosControles, ctrlValido);
    visor.innerHTML = !ctrlValido ? `Caca en ${target.id || target.name}`:'';
})