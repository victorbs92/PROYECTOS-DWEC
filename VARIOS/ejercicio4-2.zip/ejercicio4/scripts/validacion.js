/** Ejercicio 4
 * Modificar el ejercicio del FormularioPizza para que la validación
 * de los controles del formulario se realice individualmente control
 * por control utilizando eventos en los controles del formulario.
 * 
 * Los eventos deben detectar si un control no valida. A medida que se
 * detecte un fallo de validación se mostrará el mensaje de error en el visor.
 */

/* Definición de objetos */
const pedido = {
  datosEntrega: {
    nombre: document.getElementById("nombre"),
    telefono: document.getElementById("telefono"),
    direccion: document.getElementById("direccion"),
    instrucciones: document.getElementById("instrucciones"),
    toString() {
      return Object.values(this).map(e => e.value).flat().join(', ');
    },
  },

  ingredientes: {
    queso: document.getElementById("queso"),
    champi: document.getElementById("champiñones"),
    cebolla: document.getElementById("cebolla"),
    pimiento: document.getElementById("pimiento"),
    toString() {
      return Object.keys(this).reduce((acc, cur) =>
        this[cur].checked ? [...acc, cur] : acc, []).join(', ');
    },
  },

  formaPago: document.getElementById("forma-pago"),
  tamanoPizza: document.getElementsByName('tamano'),
  tiposPizza: document.getElementById("tipos"),

  resumen(visor) {
    visor.innerHTML = `<p>Datos de entrega: ${this.datosEntrega.toString()}</p>`;
    visor.innerHTML += `<p>Ingredientes: ${this.ingredientes.toString()}</p>`;
  },
};


/* Definición de funciones */
function getControles() {
  return [
    ...Object.values(pedido.datosEntrega),
    ...Object.values(pedido.ingredientes),
    pedido.formaPago,
    pedido.tiposPizza,
    ...pedido.tamanoPizza
  ];
}

function habilitarControles(controles, disabled) {
  controles.forEach(control => control.disabled = !disabled);
}

/* Definición de variables */
const visor = document.getElementById('resumen');


/* Lógica de eventos */
document.forms[0].addEventListener('focusout', function (e) {
  let ctrlValido = e.target.validity.valid;
  let mensaje = '';
  const controles = getControles();
  let otrosControles = [];

  for (let index in controles) {
    if (e.target === controles[index]) {
      continue;
    }
    otrosControles.push(controles[index]);
  }


  if (e.target.name === 'tamano') {
    otrosControles = otrosControles.filter(e => e.name !== 'tamano');
  }

  switch (e.target) {
    case pedido.datosEntrega.nombre: {
      mensaje = `<p>El nombre no coincide con ${e.target.pattern}</p>`;
      break;
    }
    case pedido.datosEntrega.telefono: {
      mensaje = '<p>El telefono telefono</p>';
      break;
    }
    case pedido.datosEntrega.direccion: {
      mensaje = '<p>caca en direccion</p>';
      break;
    }
    case pedido.tiposPizza: {
      ctrlValido = e.target.selectedIndex > 0;
      if (!ctrlValido) {
        mensaje = 'aaaaaaaa';
      }
      break;
    }
    case pedido.formaPago: {
      ctrlValido = e.target.selectedIndex > 0;
      if (!ctrlValido) {
        mensaje = 'bbbbbbbb';
      }
      break;
    }
  }

  if (e.target.name === 'tamano') {
    let ningunoSeleccionado = true;

    [...pedido.tamanoPizza].forEach(tamano => {
      ningunoSeleccionado &&= !tamano.checked;
    })

    if (ningunoSeleccionado) {
      mensaje = 'gugugug';
    }
  }

  habilitarControles(otrosControles, ctrlValido);

  if (ctrlValido) {
    visor.innerHTML = '';
  } else {
    visor.innerHTML = mensaje;
  }
})