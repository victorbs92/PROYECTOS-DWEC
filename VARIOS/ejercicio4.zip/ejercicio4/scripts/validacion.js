/** Ejercicio 4
 * Modificar el ejercicio del FormularioPizza para que la validación
 * de los controles del formulario se realice individualmente control
 * por control utilizando eventos en los controles del formulario.
 * 
 * Los eventos deben detectar si un control no valida. A medida que se
 * detecte un fallo de validación se mostrará el mensaje de error en el visor.
 */

const pedido = {
    datosEntrega: {
      nombre: document.getElementById("nombre"),
      telefono: document.getElementById("telefono"),
      direccion: document.getElementById("direccion"),
      instrucciones: document.getElementById("instrucciones"),
      toString() {
        return Object.values(this).map(e => e.value).flat().join(', ');
      },
    },
  
    ingredientes: {
      queso: document.getElementById("queso"),
      champi: document.getElementById("champiñones"),
      cebolla: document.getElementById("cebolla"),
      pimiento: document.getElementById("pimiento"),
      toString() {
        return Object.keys(this).reduce((acc, cur) =>
          this[cur].checked ? [...acc, cur] : acc, []).join(', ');
      },
    },
  
    formaPago: document.getElementById("forma-pago"),
    tiposPizza: document.getElementById("tipos"),
  
    resumen(visor) {
      visor.innerHTML = `<p>Datos de entrega: ${this.datosEntrega.toString()}</p>`;
      visor.innerHTML += `<p>Ingredientes: ${this.ingredientes.toString()}</p>`;
    },
};

const visor = document.getElementById('resumen');

document.forms[0].addEventListener('focusout', function({ target }) {
    const filtroControles = ctrl => ctrl !== target && ctrl.tagName !== 'FIELDSET';
    let otrosControles = [...document.forms[0].elements].filter(filtroControles);
    let ctrlValido = target.validity.valid;
    
    visor.innerHTML = !ctrlValido ? `Caca en ${target.id || target.name}`:'';
})