/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ejercicio8tema5;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author admin
 */
@WebService(serviceName = "Ejercicio8tema5")
public class Ejercicio8tema5 {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "operation")
    public String operation(@WebParam(name = "parameter") int parameter) {
          String caracteres="TRWAGMYFPDXBNJZSQVHLCKE";
          int resto = parameter%23;
          char letra = caracteres.charAt(resto);
          String resultado = "El DNI " + parameter + " tiene letra " + letra;
          return resultado;      
    }

    /**
     * This is a sample web service operation
     */
    
}