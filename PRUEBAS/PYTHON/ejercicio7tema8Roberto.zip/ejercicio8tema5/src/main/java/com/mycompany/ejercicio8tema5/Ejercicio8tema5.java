/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ejercicio8tema5;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 *
 * @author admin
 */
@WebService(serviceName = "Ejercicio8tema5")
public class Ejercicio8tema5 {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "operation")
    public String operation(@WebParam(name = "parameter") int parameter) {
        String caracteres = "TRWAGMYFPDXBNJZSQVHLCKE";
        int resto = parameter % 23;
        char letra = caracteres.charAt(resto);
        String resultado = "El DNI " + parameter + " tiene letra " + letra;
        return resultado;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "abuelo")
    public int abuelo(@WebParam(name = "parameter") int parameter) {
        //TODO write your implementation code here:
        try {
            String ruta = "C:/Users/admin/Desktop/filename.txt";
            String contenido = parameter + "";
            File file = new File(ruta);
            // Si el archivo no existe es creado
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(contenido);
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    
    return parameter ;
}

/**
 * This is a sample web service operation
 */
}
